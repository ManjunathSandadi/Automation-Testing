package cucumber.api.junit;

public class Cucumber {

}
