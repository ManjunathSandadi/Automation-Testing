package testRunner;

import org.junit.runner.*;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"Selenium/Features/OLALogin.feature"},
        glue = {"Selenium/src/test/java/stepDefintions/OLALoginpage.java"},
        plugin = { "html:target/selenium-Report"})

public class OLALoginrun {

}
