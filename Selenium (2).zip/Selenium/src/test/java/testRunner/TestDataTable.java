package testRunner;

import org.junit.Test;
import org.junit.runner.*;
import io.cucumber.junit.CucumberOptions;
//import junit.framework.TestCase;
//import stepDefintions.BOMData;
////@RunWith(Cucumber.class)
//@CucumberOptions(
//			features ="Selenium/Features/datatable.feature"
//,glue={"BOMData"})
//		
//	public class TestDataTable extends TestCase {
//	@Test	
//		public static void main(String args[]) {
//		//	BOMData.BOM_items_details(null);
//		}
//	
//}


//import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;


@CucumberOptions(
features = "Selenium/Features/datatable.feature"
,glue={"Selenium/src/test/java/stepDefintions/BOMData.java"}
)

public class TestDataTable  {
	
	}

