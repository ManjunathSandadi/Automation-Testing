package testRunner;

import org.junit.runner.*;

import io.cucumber.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(features = "Selenium\\Features\\Browser.feature", 
                            glue = {"Selenium\\src\\test\\java\\stepDefintions\\BrowserStepDef.java"}
                            )
public class BrowserRunner {
	
}

