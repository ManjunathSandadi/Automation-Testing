package stepDefintions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class BDDRiskTest {

	@Given("^user navigate to BOM details page$")  
	public void user_navigate_to_BOM_details_page(){
		System.out.println("user navigate to BOM details page");
	}
	
    @When ("^user select add risk option on a BOM$")
    public void user_select_add_risk_option_on_a_BOM(){
    	System.out.println("user select add risk option on a BOM");
    }    
    @And ("^user submit risk $")
    public void user_submit_risk(){
    	System.out.println("user submit risk");
    }
        
    @Then("^Risk is created for a corresponding BOM$")
    	public void risk_is_created_for_a_corresponding_BOM(){
    		System.out.println("Risk is created for a corresponding BOM");
    		
    }
}
