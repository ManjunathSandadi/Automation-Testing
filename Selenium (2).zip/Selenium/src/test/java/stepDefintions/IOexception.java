package stepDefintions;

public class IOexception extends Exception {

}
