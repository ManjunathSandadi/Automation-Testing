package stepDefintions;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Screenshot {
	public static void main(String args[]) throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Driver\\chromedriver.exe") ;
		WebDriver driver = new ChromeDriver();
		driver.get("https://olasandbox.service-now.com");
		
		File file = (((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE));
		
		FileUtils.copyFile(file, new File("C:Users\\sandadi.manjunath\\eclipse-workspace\\screenshot.jpg"));
		Thread.sleep(3000);
		driver.quit();
		
	}
//	private static TakesScreenshot driver;
//	public static void screenshot(String screen) throws IOException  {
//		 System.setProperty("webdriver.chrome.driver","C:\\Driver\\chromedriver.exe") ;      
//		    driver= new ChromeDriver();
//		    ((RemoteWebDriver) driver).get("https://olasandbox.service-now.com");
//		File file = (((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE));
//		FileUtils.copyDirectory(file, new File("C:Users/sandadi.manjunath/eclipse-workspace/Selenium/src/test/java/" +screen+".jpg"));
		
			
	}
