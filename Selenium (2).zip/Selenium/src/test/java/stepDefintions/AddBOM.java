package stepDefintions;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.*;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import io.cucumber.java.en.*;


public class AddBOM {
	
	static WebDriver driver=null;
	public static void screenshot(String screen) throws IOException  {
		File file = (((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE));
		FileUtils.copyDirectory(file, new File("C:Users/sandadi.manjunath/eclipse-workspace/Selenium/src/test/java/" +screen+".jpg"));
			
		
	}
	@SuppressWarnings("deprecation")
	@Given("^user opens browser$")
	public void user_opens_browser() {
		 System.setProperty("webdriver.chrome.driver","C:\\Driver\\chromedriver.exe") ;      
		    driver= new ChromeDriver();
		    driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);	
		    driver.manage().window().maximize();
	    
	}

	@And("^search with OLAs sandbox url$")
	public void search_with_olas_sandbox_url() throws InterruptedException, IOException {
		driver.navigate().to("https://olasandbox.service-now.com");	
		screenshot("Ola login page");
		//Thread.sleep(2500);
	    
	}

	@When("^user enters (.*) and (.*)$")
	public void user_enters_username_and_password(String username, String password) {
		driver.switchTo().frame("gsft_main");
		driver.findElement(By.xpath("//*[@id=\"user_name\"]")).sendKeys(username);
		//driver.findElement(By.id("user_name")).sendKeys("admin_npi");
		driver.findElement(By.xpath("//*[@id='user_password']")).sendKeys(password);
		
		//driver.findElement(By.id("password")).sendKeys("AdminIopex@12345");
		
	    
	}

	@And("^clicks Login$")
	public void clicks_login() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id='sysverb_login']")).click();
		Thread.sleep(2500);
	    
	}

	@When("user redirects to into homepage")
	public void user_enter_into_homepage() throws InterruptedException {
		driver.navigate().to("https://olasandbox.service-now.com/ola");
		Thread.sleep(2500); 
	    
	}
	@And("user select olas version")
	public void user_select_ola_version() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"x66a878ad47bd451084ffc472846d439a\"]/div/section[2]/div/div/div[1]/div[1]")).click();
		Thread.sleep(2500);   
		driver.findElement(By.xpath("//*[@id=\"ProductTabContent\"]/div/div[1]/div")).click();
		Thread.sleep(4000); 
	}
	@Then("User views summary tab")
	public void user_views_summary_tab() throws InterruptedException {
		Thread.sleep(3500); 
		//driver.close();
	}
	@And("click product")
	public void click_product() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"1\"]/div[1]")).click();
		Thread.sleep(3500);
		//driver.close();
	}

	@And("click ellipse")
	public void click_ellipse() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"1\"]/div[1]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"1\"]/div[2]")).click();
		Thread.sleep(3500);
		//driver.close();
	}

	@And("Click plan scope document")
	public void click_plan_scope_document() throws InterruptedException {
		//driver.findElement(By.xpath("//*[@id=\"1\"]/div[1]/ul/li[3]/a[2]")).click();
		Thread.sleep(2000);
		driver.close();
	}

	@Then("User view plan scope document")
	public void user_view_plan_scope_document() throws InterruptedException {
		Thread.sleep(5000);
		driver.close();
	}
	

}