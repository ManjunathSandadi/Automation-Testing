package stepDefintions;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import io.cucumber.java.en.*;

public class OLALoginpage {

	static WebDriver driver = null;
	static int num = 1;
	static ExtentReports report;
	static ExtentTest test;

	public static void screenshot() throws IOException {

		String screen = "C:\\Users\\sandadi.manjunath\\eclipse-workspace\\Selenium\\src\\test\\java\\screenshot" + num
				+ ".png";
		num++;
		File file = (((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE));
		FileUtils.copyFile(file, new File(screen));
	}

	public static void report() {

		report = new ExtentReports(
				System.getProperty("C:\\Users\\sandadi.manjunath\\eclipse-workspace\\Selenium\\src\\test\\java")
						+ "ReportResults.html");
		test = report.startTest("ExtentDemo");
	}

	@SuppressWarnings("deprecation")
	@Given("^user open browser$")
	public void user_open_browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);
		driver.manage().window().maximize();

	}

	@And("^search with OLA sandbox url$")
	public void search_with_ola_sandbox_url() throws InterruptedException, IOException {
		driver.navigate().to("https://olasandbox.service-now.com");
		Thread.sleep(2500);
		screenshot();
		

	}

	@When("^user enter (.*) and (.*)$")
	public void user_enter_username_and_password(String username, String password) throws IOException {
		driver.switchTo().frame("gsft_main");
		driver.findElement(By.xpath("//*[@id=\"user_name\"]")).sendKeys(username);
		// driver.findElement(By.id("user_name")).sendKeys("admin_npi");
		driver.findElement(By.xpath("//*[@id='user_password']")).sendKeys(password);
		// driver.findElement(By.id("password")).sendKeys("AdminIopex@12345");

	}

	@And("^click Login$")
	public void click_login() throws InterruptedException, IOException {
		driver.findElement(By.xpath("//*[@id='sysverb_login']")).click();
		Thread.sleep(2500);
		screenshot();


	}

	@When("user redirect to into homepage")
	public void user_enter_into_homepage() throws InterruptedException, IOException {
		driver.navigate().to("https://olasandbox.service-now.com/ola");
		Thread.sleep(2500);
		screenshot();
		

	}

	@And("user select ola version")
	public void user_select_ola_version() throws InterruptedException, IOException {
		driver.findElement(
				By.xpath("//*[@id=\"x66a878ad47bd451084ffc472846d439a\"]/div/section[2]/div/div/div[1]/div[1]"))
				.click();
		Thread.sleep(2500);
		driver.findElement(By.xpath("//*[@id=\"ProductTabContent\"]/div/div[1]/div")).click();
		Thread.sleep(4000);
	}

	@Then("User view summary tab")
	public void user_view_summary_tab() throws InterruptedException, IOException {
		Thread.sleep(3500);
		screenshot();
		driver.close();
		report();

	}

}
