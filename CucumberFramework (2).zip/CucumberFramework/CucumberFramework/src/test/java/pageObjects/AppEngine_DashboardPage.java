package pageObjects;

import org.openqa.selenium.By;

public class AppEngine_DashboardPage {
	
	public static final By dashboard=By.xpath("//a[text()=' App Engine Dashboard']");
	public static final By percentage=By.xpath("//div[@ng-show='c.data.percent']");
	public static final By red_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrRed']/..");
	public static final By yellow_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrYellow']/..");
	public static final By green_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrGreen']/..");

}
