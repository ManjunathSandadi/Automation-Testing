package stepDefinitions;


import io.cucumber.java.en.When;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
	public class BOMDataDetails {

	
		 @Given ("^User able to view BOM items data$")
		 public void User_able_to_add_BOM_items() {
			 System.out.println("User able to add BOM items");
		 }
			 
		 @When ("^BOM items details$")
		 public void BOM_items_details(DataTable dataTable) {
			 		
			 		System.out.println(dataTable);
			 	}
		  
		 @Then ("^user able to view BOM details$")
		 public void user_able_to_view_BOM_details() {
			 System.out.println("user able to view BOM details");
		 }

	 public static void main(String args[]) {
		 BOMData obj= new BOMData();
		obj.User_able_to_add_BOM_items();
		
		obj.user_able_to_view_BOM_details();
		 
		 
	 }}



