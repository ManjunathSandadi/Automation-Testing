$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("OLA_E2E.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 19,
  "name": "OLA_Feature",
  "description": "",
  "id": "ola-feature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 9207774100,
  "status": "passed"
});
formatter.background({
  "line": 21,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 22,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.result({
  "duration": 10968915700,
  "status": "passed"
});
formatter.scenario({
  "line": 70,
  "name": "Clone BOM and Edit Risk",
  "description": "",
  "id": "ola-feature;clone-bom-and-edit-risk",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 69,
      "name": "@E2E"
    }
  ]
});
formatter.step({
  "line": 71,
  "name": "I login using the valid username and the valid password",
  "keyword": "When "
});
formatter.step({
  "line": 72,
  "name": "Impersonate to \"GTM Lead\" user",
  "keyword": "Then "
});
formatter.step({
  "line": 73,
  "name": "Select \"Tokyo\" release",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 74,
      "value": "# Then Clone BOM in \"Product Content Ready\" using following details:"
    },
    {
      "line": 75,
      "value": "# | BOM                    | ShortDescription | Description | State | Category | DueDate | AddDocumentName | AddDocumentLinks | RemoveDocumentName | RemoveDependency |"
    },
    {
      "line": 76,
      "value": "#  | Test Short Description | CLONED BOM       |             |       |          |         |                 |                  |                    |                  |"
    }
  ],
  "line": 77,
  "name": "Edit Risk in \"Product Content Ready\" using following details:",
  "rows": [
    {
      "cells": [
        "Riskname",
        "BOMname",
        "ShortDescription",
        "Description",
        "Impact",
        "RiskStatus",
        "DueDate"
      ],
      "line": 78
    },
    {
      "cells": [
        "test",
        "ww",
        "Test Risk Short Description",
        "Test",
        "High",
        "Open Unmitigated",
        "05/07/2022"
      ],
      "line": 79
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "OLAStepDefs.i_login_using_valid_username_valid_password()"
});
formatter.result({
  "duration": 4610586400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GTM Lead",
      "offset": 16
    }
  ],
  "location": "OLAStepDefs.impersonate_user(String)"
});
formatter.result({
  "duration": 15071680400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tokyo",
      "offset": 8
    }
  ],
  "location": "OLAStepDefs.select_release(String)"
});
formatter.result({
  "duration": 31383739400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Product Content Ready",
      "offset": 14
    }
  ],
  "location": "OLAStepDefs.edit_risk_to_eformatter.result({
  "duration": 606555304100,
  "error_message": "org.openqa.selenium.TimeoutException: Expected condition failed: waiting for visibility of element located by By.xpath: //td[contains(text(),\u0027ww\u0027)]/..//td[text()\u003d\u0027test\u0027]/..//button (tried for 600 second(s) with 500 milliseconds interval)\nBuild info: version: \u00274.1.3\u0027, revision: \u00277b1ebf28ef\u0027\nSystem info: host: \u0027LAPTOP-5TDFFC1P\u0027, ip: \u0027192.168.29.75\u0027, os.name: \u0027Windows 11\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_333\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 101.0.4951.41, chrome: {chromedriverVersion: 101.0.4951.41 (93c720db8323..., userDataDir: C:\\Users\\ramav\\AppData\\Loca...}, goog:chromeOptions: {debuggerAddress: localhost:61961}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), se:cdp: ws://localhost:61961/devtoo..., se:cdpVersion: 101.0.4951.41, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 05643731c5a44cc5a70a4cfc9a15dfec\r\n\tat org.openqa.selenium.support.ui.WebDriverWait.timeoutException(WebDriverWait.java:87)\r\n\tat org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:231)\r\n\tat supportLibraries.ReusableMethods.waitUntilElementVisible(ReusableMethods.java:31)\r\n\tat supportLibraries.ReusableMethods.click(ReusableMethods.java:94)\r\n\tat stepDefinitions.BOTStepDefs.editrisk_to_existing_BOM(BOTStepDefs.java:250)\r\n\tat stepDefinitions.OLAStepDefs.edit_risk_to_existing_BOM(OLAStepDefs.java:69)\r\n\tat ✽.And Edit Risk \"test\" to BOM \"ww\" using following details:(OLA_E2E.feature:77)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 1067583300,
  "status": "passed"
});
stng.internal.TestInvoker$MethodInvocationAgent.invoke(TestInvoker.java:824)\r\n\tat org.testng.internal.TestInvoker.invokeTestMethods(TestInvoker.java:146)\r\n\tat org.testng.internal.TestMethodWorker.invokeTestMethods(TestMethodWorker.java:146)\r\n\tat org.testng.internal.TestMethodWorker.run(TestMethodWorker.java:128)\r\n\tat java.util.ArrayList.forEach(Unknown Source)\r\n\tat org.testng.TestRunner.privateRun(TestRunner.java:794)\r\n\tat org.testng.TestRunner.run(TestRunner.java:596)\r\n\tat org.testng.SuiteRunner.runTest(SuiteRunner.java:377)\r\n\tat org.testng.SuiteRunner.access$000(SuiteRunner.java:28)\r\n\tat org.testng.SuiteRunner$SuiteWorker.run(SuiteRunner.java:418)\r\n\tat org.testng.internal.thread.ThreadUtil.lambda$execute$0(ThreadUtil.java:64)\r\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\r\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\r\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\r\n\tat java.lang.Thread.run(Unknown Source)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 1183172200,
  "status": "passed"
});
});