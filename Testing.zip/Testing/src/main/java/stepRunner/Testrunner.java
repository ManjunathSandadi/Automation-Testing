package stepRunner;

import cucumber.api.CucumberOptions;


@CucumberOptions(
		features = "src/test/resources/feature",
		glue = {"TestStep"},
		tags = {"@OLA"}, monochrome = true, 
		plugin ={"pretty", "html:target/cucumber-report/E2E"})


public class Testrunner {
	

}
