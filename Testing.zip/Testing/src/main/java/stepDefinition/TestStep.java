package stepDefinition;


import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.*;



public class TestStep {

	static ExtentReports report;
	static ExtentTest test;
	static WebDriver driver=null;
	static int num=1;

    @BeforeClass
    public void startTest()  {
        report = new ExtentReports(System.getProperty("C:\\Users\\sandadi.manjunath\\eclipse-workspace\\Testing\\src\\main\\java")+"ReportResults.html");
        test = report.startTest("ExtentDemo");
        }
	public static void screenshot() throws IOException {
		

		String screen = "C:\\Users\\sandadi.manjunath\\eclipse-workspace\\Testing\\src\\main\\java\\screen" + num
				+ ".png";
		num++;
		File file = (((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE));
		FileUtils.copyFile(file, new File(screen));
	}


	@Given("^user open browser$")
	public void user_open_browser() {
		System.setProperty("webdriver.chrome.driver", "C://Driver//chromedriver.exe");
    	driver = new ChromeDriver();
  
	}
	
	@And("^search with OLA sandbox url$")
	public void search_with_OLA_sandbox_url() throws IOException, InterruptedException {
		driver.navigate().to("https://olasandbox.service-now.com");
		Thread.sleep(2500);
		screenshot();
	}
	
	@When("^user enter (.*) and (.*)$")
	public void user_enter_admin_npi_and_AdminIopex(String username,String password) throws InterruptedException, IOException {
		//driver.switchTo().frame("gsft_main");
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(username);
		Thread.sleep(2500);
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
		screenshot();
		Thread.sleep(2500);	
		
	}
	
	@When("^click Login$")
	public void click_Login() throws InterruptedException {
		driver.findElement(
				By.xpath("//*[@id=\"x79e5205bcb31120000f8d856634c9c5e\"]/div/form/div/div/div[2]/div/div[2]/button"))
				.click();
		Thread.sleep(3500);
	    
	}
	
	@When("^user redirect to into homepage$")
	public void user_redirect_to_into_homepage() throws InterruptedException, IOException {
		driver.navigate().to("https://olasandbox.service-now.com/ola");
		Thread.sleep(3000);
		screenshot();
	    
	}
	
	@When("^user select ola version$")
	public void user_select_ola_version() throws InterruptedException, IOException {
		driver.findElement(
				By.xpath("//*[@id=\"x66a878ad47bd451084ffc472846d439a\"]/div/section[2]/div/div/div[1]/div[1]"))
				.click();
		Thread.sleep(2500);
		screenshot();
		driver.findElement(By.xpath("//*[@id=\"ProductTabContent\"]/div/div[1]/div")).click();
		Thread.sleep(4000);
	
	}
	
	@Then("^User view summary tab$")
	public void user_view_summary_tab() throws InterruptedException, IOException {
		Thread.sleep(3500);
		screenshot();
	   
	}
	
	@Given("^Open Browser$")
	public void open_Browser() {
		driver.navigate().to("https://developer.servicenow.com");
	    
	}
	
	@When("^User type (.*) and (.*)$")
	public void user_type_sandadimanjunath_gmail_com_and_Manjunath(String email,String password) throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(email);
		Thread.sleep(2500);
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
		
	   
	}
	
	@When("^Select Login$")
	public void select_Login() {
	    
	}
	
	@Then("^User enter into servicenow$")
	public void user_enter_into_servicenow() {
	  
	}
	
	@AfterClass
	public void endTest()
	{
	report.endTest(test);
	test.log(LogStatus.PASS,"Test Passed");
	test.log(LogStatus.FAIL,"Test Failed");
	test.log(LogStatus.SKIP,"Test Skipped");
	test.log(LogStatus.INFO,"Test Info");
	report.flush();
	}
	
	

}
