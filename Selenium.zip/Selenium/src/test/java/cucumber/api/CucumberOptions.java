package cucumber.api;

public interface CucumberOptions {

}
