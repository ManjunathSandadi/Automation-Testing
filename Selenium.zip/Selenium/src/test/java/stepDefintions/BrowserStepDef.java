package stepDefintions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Given;

public class BrowserStepDef {
	WebDriver driver= null;

	@SuppressWarnings("deprecation")
	@Given("^User open Brower$")
	public void user_open_brower() {
	    System.out.println("working 1");
	    System.setProperty("webdriver.chrome.driver","C:\\Driver\\chromedriver.exe") ;      
	    driver= new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);	
	    driver.manage().window().maximize();
	  
	}

	@And ("^User is on google page$")
	public void user_is_on_google_page() {
		System.out.println("working 2");
		driver.navigate().to("https://google.com");
		//driver.navigate().to("https://ola.com");
		  //driver.close();
	}

	@When("user search keyword")
	public void user_search_keyword() throws InterruptedException {
		System.out.println("working 3");
		driver.findElement(By.name("q")).sendKeys("servicenow developer");
		//driver.findElement(By.xpath("//*[@id='user_name']")).sendKeys("Admin_npi");
		Thread.sleep(3000);
	}

	@And("click enter")
	public void click_enter() {
		System.out.println("working 4");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
	}

	@Then("user view keyword result")
	public void user_view_keyword_result() throws InterruptedException {
		System.out.println("working 5");
		Thread.sleep(3000);
		driver.quit();
		
		
	}
}
