package stepDefintions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;


public class OLALoginpage {
	
	WebDriver driver=null;
	@SuppressWarnings("deprecation")
	@Given("^user open browser$")
	public void user_open_browser() {
		 System.setProperty("webdriver.chrome.driver","C:\\Driver\\chromedriver.exe") ;      
		    driver= new ChromeDriver();
		    driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);	
		    driver.manage().window().maximize();
	    
	}

	@And("^search with OLA sandbox url$")
	public void search_with_ola_sandbox_url() throws InterruptedException {
		driver.navigate().to("https://olasandbox.service-now.com");
		//Thread.sleep(2500);
	    
	}

	@When("^user enter (.*) and (.*)$")
	public void user_enter_username_and_password(String username, String password) {
		driver.switchTo().frame("gsft_main");
		driver.findElement(By.xpath("//*[@id=\"user_name\"]")).sendKeys(username);
		//driver.findElement(By.id("user_name")).sendKeys("admin_npi");
		driver.findElement(By.xpath("//*[@id='user_password']")).sendKeys(password);
		
		//driver.findElement(By.id("password")).sendKeys("AdminIopex@12345");
		
	    
	}

	@And("^click Login$")
	public void click_login() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id='sysverb_login']")).click();
		Thread.sleep(2500);
	    
	}

	@When("user redirect to into homepage")
	public void user_enter_into_homepage() throws InterruptedException {
		driver.navigate().to("https://olasandbox.service-now.com/ola");
		Thread.sleep(2500); 
	    
	}
	@And("user select ola version")
	public void user_select_ola_version() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"x66a878ad47bd451084ffc472846d439a\"]/div/section[2]/div/div/div[1]/div[1]")).click();
		Thread.sleep(2500);   
		driver.findElement(By.xpath("//*[@id=\"ProductTabContent\"]/div/div[1]/div")).click();
		Thread.sleep(4000); 
	}
	@Then("User view summary tab")
	public void user_view_summary_tab() throws InterruptedException {
		Thread.sleep(3500);  
		driver.close();
	   
	}

}
