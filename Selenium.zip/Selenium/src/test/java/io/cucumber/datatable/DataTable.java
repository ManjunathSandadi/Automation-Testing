package io.cucumber.datatable;

public @interface DataTable {

}
