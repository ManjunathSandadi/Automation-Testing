$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/features/RYG_rules.feature");
formatter.feature({
  "line": 1,
  "name": "RYG_Rules",
  "description": "I want to use this template for my feature file",
  "id": "ryg-rules",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4660648901,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.result({
  "duration": 12981379400,
  "status": "passed"
});
formatter.scenario({
  "line": 109,
  "name": "Risk Workstream level -\u003e High + Mitigation plan \u003d Yellow",
  "description": "",
  "id": "ryg-rules;risk-workstream-level--\u003e-high-+-mitigation-plan-\u003d-yellow",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 108,
      "name": "@E2E"
    }
  ]
});
formatter.step({
  "line": 110,
  "name": "I login using the valid username and the valid password",
  "keyword": "When "
});
formatter.step({
  "line": 111,
  "name": "Impersonate to \"GTM Lead\" user",
  "keyword": "Then "
});
formatter.step({
  "line": 112,
  "name": "Select \"Tokyo\" release",
  "keyword": "And "
});
formatter.step({
  "line": 113,
  "name": "Select Page \"Detailed View\"",
  "keyword": "And "
});
formatter.step({
  "line": 114,
  "name": "Add Risk to Workstream \"Ready to Solve\" using following details:",
  "rows": [
    {
      "cells": [
        "ShortDescription",
        "Description",
        "Impact",
        "RiskStatus",
        "MitigationPlan",
        "DueDate"
      ],
      "line": 115
    },
    {
      "cells": [
        "Test Risk  1 Short Description",
        "Test",
        "High",
        "Open with Mitigation Plan",
        "Mitigation Plan",
        "12/07/2022"
      ],
      "line": 116
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 117,
  "name": "validate Risk which should be in \"Yellow\" for Workstream \"Ready to Solve\"",
  "keyword": "And "
});
formatter.match({
  "location": "OLAStepDefs.i_login_using_valid_username_valid_password()"
});
formatter.result({
  "duration": 626958000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GTM Lead",
      "offset": 16
    }
  ],
  "location": "OLAStepDefs.impersonate_user(String)"
});
formatter.result({
  "duration": 24700378300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tokyo",
      "offset": 8
    }
  ],
  "location": "OLAStepDefs.select_release(String)"
});
formatter.result({
  "duration": 72651791599,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Detailed View",
      "offset": 13
    }
  ],
  "location": "OLAStepDefs.select_page(String)"
});
formatter.result({
  "duration": 53190214301,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Ready to Solve",
      "offset": 24
    }
  ],
  "location": "OLAStepDefs.add_risk_to_a_workstream(String,DataTable)"
});
formatter.result({
  "duration": 365313174301,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Yellow",
      "offset": 34
    },
    {
      "val": "Ready to Solve",
      "offset": 58
    }
  ],
  "location": "OLAStepDefs.risk_to_a_workstream_rules(String,String)"
});
formatter.result({
  "duration": 10086799,
  "status": "passed"
});
formatter.after({
  "duration": 760112799,
  "status": "passed"
});
