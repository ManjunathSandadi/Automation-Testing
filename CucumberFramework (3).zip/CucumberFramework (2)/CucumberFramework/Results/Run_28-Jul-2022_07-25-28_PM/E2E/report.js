$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/features/RYG_rules.feature");
formatter.feature({
  "line": 1,
  "name": "RYG_Rules",
  "description": "I want to use this template for my feature file",
  "id": "ryg-rules",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4703866400,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.result({
  "duration": 9997911901,
  "status": "passed"
});
formatter.scenario({
  "line": 131,
  "name": "Bulk Update - Deatiled View tab:",
  "description": "",
  "id": "ryg-rules;bulk-update---deatiled-view-tab:",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 130,
      "name": "@E2E"
    }
  ]
});
formatter.step({
  "line": 132,
  "name": "I login using the valid username and the valid password",
  "keyword": "When "
});
formatter.step({
  "line": 133,
  "name": "Impersonate to \"GTM Lead\" user",
  "keyword": "Then "
});
formatter.step({
  "line": 134,
  "name": "Select \"Tokyo\" release",
  "keyword": "And "
});
formatter.step({
  "line": 135,
  "name": "Select Page \"Detailed View\"",
  "keyword": "And "
});
formatter.step({
  "line": 136,
  "name": "Bulk Update in Workstream \"Ready to Solve\" using following details",
  "rows": [
    {
      "cells": [
        "BOM Category",
        "BOM Name",
        "Assigned to",
        "State",
        "Status"
      ],
      "line": 137
    },
    {
      "cells": [
        "Enablement",
        "Copy of Delta Presentation and Recording",
        "",
        "Work in Progress",
        "Red"
      ],
      "line": 138
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "OLAStepDefs.i_login_using_valid_username_valid_password()"
});
formatter.result({
  "duration": 624740000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GTM Lead",
      "offset": 16
    }
  ],
  "location": "OLAStepDefs.impersonate_user(String)"
});
formatter.result({
  "duration": 22156594099,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tokyo",
      "offset": 8
    }
  ],
  "location": "OLAStepDefs.select_release(String)"
});
formatter.result({
  "duration": 72583937701,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Detailed View",
      "offset": 13
    }
  ],
  "location": "OLAStepDefs.select_page(String)"
});
formatter.result({
  "duration": 50934769900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Ready to Solve",
      "offset": 27
    }
  ],
  "location": "OLAStepDefs.select_checkbox(DataTable)"
});
formatter.result({
  "duration": 243200,
  "error_message": "cucumber.runtime.CucumberException: Arity mismatch: Step Definition \u0027stepDefinitions.OLAStepDefs.select_checkbox(DataTable) in file:/C:/Users/pavan.balireddy/Downloads/CucumberFramework%20(2)/CucumberFramework/target/test-classes/\u0027 with pattern [^Bulk Update in Workstream \"([^\"]*)\" using following details$] is declared with 1 parameters. However, the gherkin step has 2 arguments [Ready to Solve, Table:[[BOM Category, BOM Name, Assigned to, State, Status], [Enablement, Copy of Delta Presentation and Recording, , Work in Progress, Red]]]. \nStep: Then Bulk Update in Workstream \"Ready to Solve\" using following details\r\n\tat cucumber.runtime.StepDefinitionMatch.arityMismatch(StepDefinitionMatch.java:102)\r\n\tat cucumber.runtime.StepDefinitionMatch.transformedArgs(StepDefinitionMatch.java:60)\r\n\tat cucumber.runtime.StepDefinitionMatch.runStep(StepDefinitionMatch.java:37)\r\n\tat cucumber.runtime.Runtime.runStep(Runtime.java:300)\r\n\tat cucumber.runtime.model.StepContainer.runStep(StepContainer.java:44)\r\n\tat cucumber.runtime.model.StepContainer.runSteps(StepContainer.java:39)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:44)\r\n\tat cucumber.runtime.model.CucumberFeature.run(CucumberFeature.java:165)\r\n\tat cucumber.api.testng.TestNGCucumberRunner.runCucumber(TestNGCucumberRunner.java:63)\r\n\tat TestNGrunners.RunCucumberTests_RYG.feature(RunCucumberTests_RYG.java:42)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat java.lang.reflect.Method.invoke(Method.java:498)\r\n\tat org.testng.internal.MethodInvocationHelper.invokeMethod(MethodInvocationHelper.java:133)\r\n\tat org.testng.internal.TestInvoker.invokeMethod(TestInvoker.java:598)\r\n\tat org.testng.internal.TestInvoker.invokeTestMethod(TestInvoker.java:173)\r\n\tat org.testng.internal.MethodRunner.runInSequence(MethodRunner.java:46)\r\n\tat org.testng.internal.TestInvoker$MethodInvocationAgent.invoke(TestInvoker.java:824)\r\n\tat org.testng.internal.TestInvoker.invokeTestMethods(TestInvoker.java:146)\r\n\tat org.testng.internal.TestMethodWorker.invokeTestMethods(TestMethodWorker.java:146)\r\n\tat org.testng.internal.TestMethodWorker.run(TestMethodWorker.java:128)\r\n\tat java.util.ArrayList.forEach(ArrayList.java:1259)\r\n\tat org.testng.TestRunner.privateRun(TestRunner.java:794)\r\n\tat org.testng.TestRunner.run(TestRunner.java:596)\r\n\tat org.testng.SuiteRunner.runTest(SuiteRunner.java:377)\r\n\tat org.testng.SuiteRunner.access$000(SuiteRunner.java:28)\r\n\tat org.testng.SuiteRunner$SuiteWorker.run(SuiteRunner.java:418)\r\n\tat org.testng.internal.thread.ThreadUtil.lambda$execute$0(ThreadUtil.java:64)\r\n\tat java.util.concurrent.FutureTask.run(FutureTask.java:266)\r\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1149)\r\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)\r\n\tat java.lang.Thread.run(Thread.java:750)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 714565800,
  "status": "passed"
});
