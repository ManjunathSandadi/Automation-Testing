$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/features/RYG_rules.feature");
formatter.feature({
  "line": 1,
  "name": "RYG_Rules",
  "description": "I want to use this template for my feature file",
  "id": "ryg-rules",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4689350600,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.result({
  "duration": 11264742100,
  "status": "passed"
});
formatter.scenario({
  "line": 131,
  "name": "Bulk Update - Deatiled View tab:",
  "description": "",
  "id": "ryg-rules;bulk-update---deatiled-view-tab:",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 130,
      "name": "@E2E"
    }
  ]
});
formatter.step({
  "line": 132,
  "name": "I login using the valid username and the valid password",
  "keyword": "When "
});
formatter.step({
  "line": 133,
  "name": "Impersonate to \"GTM Lead\" user",
  "keyword": "Then "
});
formatter.step({
  "line": 134,
  "name": "Select \"Tokyo\" release",
  "keyword": "And "
});
formatter.step({
  "line": 135,
  "name": "Select Page \"Detailed View\"",
  "keyword": "And "
});
formatter.step({
  "line": 136,
  "name": "Bulk Update in Workstream \"Ready to Solve\" using following details",
  "rows": [
    {
      "cells": [
        "BOMCategory",
        "BOMName",
        "Assignedto",
        "State",
        "Status"
      ],
      "line": 137
    },
    {
      "cells": [
        "Enablement",
        "Copy of Delta Presentation and Recording",
        "",
        "Work in Progress",
        "Red"
      ],
      "line": 138
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "OLAStepDefs.i_login_using_valid_username_valid_password()"
});
formatter.result({
  "duration": 645548200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GTM Lead",
      "offset": 16
    }
  ],
  "location": "OLAStepDefs.impersonate_user(String)"
});
formatter.result({
  "duration": 24003036400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tokyo",
      "offset": 8
    }
  ],
  "location": "OLAStepDefs.select_release(String)"
});
formatter.result({
  "duration": 73047120700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Detailed View",
      "offset": 13
    }
  ],
  "location": "OLAStepDefs.select_page(String)"
});
formatter.result({
  "duration": 52047071200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Ready to Solve",
      "offset": 27
    }
  ],
  "location": "OLAStepDefs.select_checkbox(String,DataTable)"
});
formatter.result({
  "duration": 101291321700,
  "status": "passed"
});
formatter.after({
  "duration": 794137700,
  "status": "passed"
});
