package supportLibraries;

import java.io.File;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.itextpdf.text.log.SysoCounter;


public class ReusableMethods {
	//static ExtentTest test;
	//static ExtentReports report;
	static WebDriver driver = DriverManager.getWebDriver();
	private static long timeOutInSeconds = 600,min_timeOutInSeconds = 150;
	
	public static void ExtentReport() {
		//report = new ExtentReports(System.getProperty("user.dir")+"ExtentReportResults.html");
		//test.log(LogStatus.FAIL,test.addScreenCapture(capture(driver))+ "Test Failed");
	}
	public static String capture(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("src/../BStackImages/" + System.currentTimeMillis()
		+ ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}
	/**
	 * Function to wait until the specified element is visible
	 * 
	 * @param by
	 *            The {@link WebDriver} locator used to identify the element
	 * @param timeOutInSeconds
	 *            The wait timeout in seconds
	 */
	public static void waitUntilElementVisible(By by) {
		(new WebDriverWait(driver, Duration.ofSeconds(timeOutInSeconds))).until(ExpectedConditions
				.visibilityOfElementLocated(by));
		driver.manage().timeouts().implicitlyWait(70,TimeUnit.SECONDS);
	}

	/**
	 * Function to wait until the specified element is enabled
	 * 
	 * @param by
	 *            The {@link WebDriver} locator used to identify the element
	 * @param timeOutInSeconds
	 *            The wait timeout in seconds
	 */
	public static void waitUntilElementEnabled(By by) {
		(new WebDriverWait(driver, Duration.ofSeconds(timeOutInSeconds))).until(ExpectedConditions
				.elementToBeClickable(by));
		driver.manage().timeouts().implicitlyWait(70,TimeUnit.SECONDS);
	}

	/**
	 * Function to wait until the specified element is disabled
	 * 
	 * @param by
	 *            The {@link WebDriver} locator used to identify the element
	 * @param timeOutInSeconds
	 *            The wait timeout in seconds
	 */
	public static void waitUntilElementDisabled(By by) {
		(new WebDriverWait(driver, Duration.ofSeconds(min_timeOutInSeconds))).until(ExpectedConditions
				.not(ExpectedConditions.elementToBeClickable(by)));
	}

	public static void enterData(By element, String value) {
		if (!value.equals("")) {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			waitForLoad();
			driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
			driver.findElement(element).clear();
			driver.findElement(element).click();
			driver.manage().timeouts().implicitlyWait(80,TimeUnit.SECONDS);
			driver.findElement(element).sendKeys(value);
			driver.manage().timeouts().implicitlyWait(70,TimeUnit.SECONDS);
			driver.findElement(element).sendKeys(Keys.TAB);	
			driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		}
	}

	public static void enterData_without_TAB(By element, String value) {
		if (!value.equals("")) {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			waitForLoad();
			driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
			driver.findElement(element).clear();
			driver.findElement(element).click();
			driver.manage().timeouts().implicitlyWait(80,TimeUnit.SECONDS);
			driver.findElement(element).sendKeys(value);
			driver.manage().timeouts().implicitlyWait(70,TimeUnit.SECONDS);
		}
	}

	public static void highlight(By element) throws InterruptedException {
		waitForLoad();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Wb = driver.findElement(element);
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", Wb, " outline: #f00 solid 2px;");
	}

	public static void click(By element) throws InterruptedException {
		waitUntilElementVisible(element);
		waitUntilElementEnabled(element);
		waitForLoad();
		driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
		scrollToview(element);
		highlight(element);
		driver.findElement(element).click();
		driver.manage().timeouts().implicitlyWait(80,TimeUnit.SECONDS);
	}

	public static void clickJS(By element) {
		try {
			if (driver.findElement(element).isDisplayed()) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				waitForLoad();
				driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
				JavascriptExecutor js=(JavascriptExecutor) driver;
				//js.executeScript("arguments[0].scrollIntoView(true);", element);
				js.executeScript("arguments[0].click();", driver.findElement(element));
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}		
	}

	public static void click(String element) {
		try {
			if (driver.findElement(By.xpath(element)).isDisplayed()) {
				waitForLoad();
				driver.manage().timeouts().implicitlyWait(80,TimeUnit.SECONDS);
				scrollToview(By.xpath(element));	
				highlight(By.xpath(element));
				waitUntilElementVisible((By.xpath(element)));
				waitUntilElementEnabled((By.xpath(element)));
				waitForLoad();

				driver.findElement(By.xpath(element)).click();
				driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void selectDataByVisibleText(By element, String value) {
		if(!value.equals("")) {
			try {
				if (driver.findElement(element).isDisplayed()) {
					waitUntilElementVisible(element);
					waitUntilElementEnabled(element);
					waitForLoad();
					Select select=new Select(driver.findElement(element));
					select.selectByVisibleText(value);	
				}
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public static void waitForLoad() {
		try {
			new WebDriverWait(driver,Duration.ofSeconds(timeOutInSeconds)).until(webDriver -> ((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState").equals("complete"));
		} catch (Throwable error) {
			System.out.println(error);
			System.out.println("TimeOut Failed");
		}
	}

	public static void softAssertverification(String actual_message, String expected_message) {
		waitForLoad();
		SoftAssert softassert=new SoftAssert();
		softassert.assertEquals(actual_message, expected_message,"Message validation completed succesfully");
	}
	public static void softAssertverification(boolean actual_status, boolean expected_status) {
		waitForLoad();
		SoftAssert softassert=new SoftAssert();
		softassert.assertEquals(actual_status, expected_status,"Validation completed successfully");
		System.out.println("Expected Status= "+expected_status+", Actual Status= "+actual_status);
	}
	public static void scrollToview(By element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(element));
		actions.perform();
	}
	public static void selectCheckbox(By element) throws InterruptedException {
		if (!driver.findElement(element).isSelected()) {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			waitForLoad();
			driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
			driver.findElement(element).click();
			Thread.sleep(10000);
		}
	}
	public static String getText(By WebElement) {
		return driver.findElement(WebElement).getText().trim();
	}

	public static void softAssertverification(long actual, long expected) {
		waitForLoad();
		SoftAssert softassert=new SoftAssert();
		softassert.assertEquals(actual, expected,"Expected = "+expected+ "Actual = "+actual);
	}
	public static void IsElementExists(By element, boolean value, String field) {
		waitForLoad();
		if(value==true) {
			try {
				if(driver.findElement(element).isDisplayed()) {
					System.out.println("Element = '"+field+"' exists in UI which is expected");
				}	
			}catch(Exception e) {
				System.out.println("Element = '"+field+"' NOT exists in UI which is NOT expected");
			}
		}else {
			try {
				if(!driver.findElement(element).isDisplayed()) {
					System.out.println("Element = '"+field+"' NOT exists in UI which is expected");
				}	
			}catch(Exception e) {
				System.out.println("Element = '"+field+"' exists in UI which is NOT expected");
			}
		}
	}

	public static String two_decimal_places(double value) {
		DecimalFormat df = new DecimalFormat("0.00");
		System.out.println("double : " + df.format(value)); 
		return df.format(value);
	}
}