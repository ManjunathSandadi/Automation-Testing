package pageObjects;

import org.openqa.selenium.By;

public class LoginPage {
	public static String impersonateUser;
	public static By pageCount;
	public static By pageNavigate;
	public static final By userName = By.id("username");
	public static final By password = By.id("password");
	public static final By login = By.xpath("//button[@name='login']");
	public static final By userDropdown = By.xpath("//button[@id='user_info_dropdown']");
	public static final By btnImpersonateUser = By.xpath("//html//body//*[@id='glide_ui_impersonator']");
	public static final By searchForUser = By.xpath("//span[text()='Search for user']/..");
	public static final By userSearchInputBox = By.xpath("//input[@id='s2id_autogen2_search']");
	public static final By dialogBoxImpersonateUser = By.xpath("//h4[contains(text(),'Impersonate User')]");
	
	public static void setImpersonateUser(String user) {
		impersonateUser="//div[text()='"+user+"']/..";
	}

	public static void setPageNavigate(int pageNum) {
		// TODO Auto-generated method stub
		
	}
	
}
