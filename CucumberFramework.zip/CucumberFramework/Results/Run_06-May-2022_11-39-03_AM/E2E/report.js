$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("OLA_E2E.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 19,
  "name": "OLA_Feature",
  "description": "",
  "id": "ola-feature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 10200729800,
  "status": "passed"
});
formatter.background({
  "line": 21,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 22,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.result({
  "duration": 5323010400,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: net::ERR_NAME_NOT_RESOLVED\n  (Session info: chrome\u003d101.0.4951.41)\nBuild info: version: \u00274.1.3\u0027, revision: \u00277b1ebf28ef\u0027\nSystem info: host: \u0027LAPTOP-5TDFFC1P\u0027, ip: \u0027192.168.29.75\u0027, os.name: \u0027Windows 11\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_333\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCommand: [38011065a3c116412b4248e76b07788f, get {url\u003dhttps://olasandbox.service-now.com}]\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 101.0.4951.41, chrome: {chromedriverVersion: 101.0.4951.41 (93c720db8323..., userDataDir: C:\\Users\\ramav\\AppData\\Loca...}, goog:chromeOptions: {debuggerAddress: localhost:55161}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), se:cdp: ws://localhost:55161/devtoo..., se:cdpVersion: 101.0.4951.41, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 38011065a3c116412b4248e76b07788f\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.codec.w3c.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:200)\r\n\tat org.openqa.selenium.remote.codec.w3c.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:133)\r\n\tat org.openqa.selenium.remote.codec.w3c.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:53)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:184)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.invokeExecute(DriverCommandExecutor.java:167)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:142)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:567)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.get(RemoteWebDriver.java:330)\r\n\tat stepDefinitions.GeneralStepDefs.i_am_in_login_page(GeneralStepDefs.java:26)\r\n\tat ✽.Given I am in the login page of the application(OLA_E2E.feature:22)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 25,
  "name": "Impersonate user",
  "description": "",
  "id": "ola-feature;impersonate-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 24,
      "name": "@E2E"
    }
  ]
});
formatter.step({
  "line": 26,
  "name": "I login using the valid username and the valid password",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "Impersonate to \"GTM Lead\" user",
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "Select \"Tokyo\" release",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "Add BOM to \"Product Content Ready\" using following details:",
  "rows": [
    {
      "cells": [
        "ShortDescription",
        "Description",
        "State",
        "Category",
        "DueDate"
      ],
      "line": 30
    },
    {
      "cells": [
        "Test Short Description",
        "Test",
        "Open",
        "General",
        "05/07/2022"
      ],
      "line": 31
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "Add Risk to BOM \"Test Short Description\" using following details:",
  "rows": [
    {
      "cells": [
        "ShortDescription",
        "Description",
        "Impact",
        "RiskStatus",
        "DueDate"
      ],
      "line": 33
    },
    {
      "cells": [
        "Test Risk Short Description",
        "Test",
        "High",
        "Open Unmitigated",
        "05/07/2022"
      ],
      "line": 34
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "OLAStepDefs.i_login_using_valid_username_valid_password()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "GTM Lead",
      "offset": 16
    }
  ],
  "location": "OLAStepDefs.impersonate_user(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Tokyo",
      "offset": 8
    }
  ],
  "location": "OLAStepDefs.select_release(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Product Content Ready",
      "offset": 12
    }
  ],
  "location": "OLAStepDefs.add_BOM(String,DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Short Description",
      "offset": 17
    }
  ],
  "location": "OLAStepDefs.add_risk_to_existing_BOM(String,DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 1049613000,
  "status": "passed"
});
