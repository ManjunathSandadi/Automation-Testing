$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("OLA_E2E.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 19,
  "name": "OLA_Feature",
  "description": "",
  "id": "ola-feature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 8614471300,
  "status": "passed"
});
formatter.background({
  "line": 21,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 22,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.result({
  "duration": 11361192900,
  "status": "passed"
});
formatter.scenario({
  "line": 57,
  "name": "Add and Remove Documents",
  "description": "",
  "id": "ola-feature;add-and-remove-documents",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 56,
      "name": "@E2E"
    }
  ]
});
formatter.step({
  "line": 58,
  "name": "I login using the valid username and the valid password",
  "keyword": "When "
});
formatter.step({
  "line": 59,
  "name": "Impersonate to \"GTM Lead\" user",
  "keyword": "Then "
});
formatter.step({
  "line": 60,
  "name": "Select \"Tokyo\" release",
  "keyword": "And "
});
formatter.step({
  "line": 61,
  "name": "Add Document using following details:",
  "rows": [
    {
      "cells": [
        "DocumentName",
        "DocumentLinks"
      ],
      "line": 62
    },
    {
      "cells": [
        "Doc1",
        "Sample1"
      ],
      "line": 63
    },
    {
      "cells": [
        "Doc2",
        "Sample2"
      ],
      "line": 64
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 65,
  "name": "Remove Document using following details:",
  "rows": [
    {
      "cells": [
        "DocumentName"
      ],
      "line": 66
    },
    {
      "cells": [
        "Doc1"
      ],
      "line": 67
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "OLAStepDefs.i_login_using_valid_username_valid_password()"
});
formatter.result({
  "duration": 5204850500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GTM Lead",
      "offset": 16
    }
  ],
  "location": "OLAStepDefs.impersonate_user(String)"
});
formatter.result({
  "duration": 116744607800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tokyo",
      "offset": 8
    }
  ],
  "location": "OLAStepDefs.select_release(String)"
});
formatter.result({
  "duration": 32199534000,
  "status": "passed"
});
formatter.match({
  "location": "OLAStepDefs.add_document(DataTable)"
});
formatter.result({
  "duration": 237265247200,
  "status": "passed"
});
formatter.match({
  "location": "OLAStepDefs.remove_document(DataTable)"
});
formatter.result({
  "duration": 2807196122400,
  "error_message": "org.openqa.selenium.TimeoutException: Expected condition failed: waiting for element to be clickable: By.xpath: //h4[text()\u003d\u0027Doc1\u0027]/../../button (tried for 1000 second(s) with 500 milliseconds interval)\nBuild info: version: \u00274.1.3\u0027, revision: \u00277b1ebf28ef\u0027\nSystem info: host: \u0027LAPTOP-5TDFFC1P\u0027, ip: \u0027192.168.29.75\u0027, os.name: \u0027Windows 11\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_333\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 101.0.4951.41, chrome: {chromedriverVersion: 101.0.4951.41 (93c720db8323..., userDataDir: C:\\Users\\ramav\\AppData\\Loca...}, goog:chromeOptions: {debuggerAddress: localhost:57014}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), se:cdp: ws://localhost:57014/devtoo..., se:cdpVersion: 101.0.4951.41, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 7e8966639714daef8f844687e12f8806\r\n\tat org.openqa.selenium.support.ui.WebDriverWait.timeoutException(WebDriverWait.java:87)\r\n\tat org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:231)\r\n\tat supportLibraries.ReusableMethods.waitUntilElementEnabled(ReusableMethods.java:44)\r\n\tat supportLibraries.ReusableMethods.click(ReusableMethods.java:91)\r\n\tat stepDefinitions.BOTStepDefs.remove_document(BOTStepDefs.java:325)\r\n\tat stepDefinitions.OLAStepDefs.remove_document(OLAStepDefs.java:187)\r\n\tat ✽.Then Remove Document using following details:(OLA_E2E.feature:65)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 1742012800,
  "status": "passed"
});
