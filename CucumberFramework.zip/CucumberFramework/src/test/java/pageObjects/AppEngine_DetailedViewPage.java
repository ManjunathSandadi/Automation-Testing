package pageObjects;

import org.openqa.selenium.By;

public class AppEngine_DetailedViewPage {

	public static String projectRelease;
	public static String addedBomOptionsButton,addRiskToBOM,addDependencyToBOM;
	public static String workStream,workStreamAddRisk,workStreamButton,workStreamAddBom;
	public static String view_editBom,copy_cloneBom;
	public static String workStream_overall_status;

	public static final By btnGoToMarket =By.xpath("//button[text()='GTM']");
	public static final By deliverables_overview = By.xpath("//*[contains(text(),'Deliverables Overview')]");

	public static final By BOM_short_desc=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By BOM_desc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.Desc']");
	public static final By BOM_category=By.xpath("//select[@ng-model='c.newbomcat_value']");
	public static final By BOM_partner=By.xpath("//select[@ng-model='c.newpartner_value']");
	public static final By BOM_type=By.xpath("//select[@ng-model='c.newbomtype_value']");
	public static final By BOM_state=By.xpath("//select[@ng-model='c.newstate_value']");
	public static final By BOM_due_date=By.xpath("//input[@id='sp_formfield_' and @ng-model='formattedDate']");

	public static final By clone_BOM_short_desc=By.xpath("//label[@for='BomDescription']/../input");
	public static final By clone_BOM_desc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.newdesc_value']");	
	public static final By add_document_to_BOM=By.xpath("//button[@ng-click='c.addLinkBOM()']");	
	public static final By document_name_BOM=By.xpath("//input[@ng-model='c.data.u_name']");
	public static final By document_link_BOM=By.xpath("//input[@ng-model='c.data.u_link']");
	public static final By add=By.xpath("//button[@id='add_link']");
	public static String remove_document_name,remove_BOM_document_name;

	//textarea[@id='BomShortDescription']
	//input[@ng-model='c.isCloneRisk']
	//input[@ng-model='c.isCloneDepen']
	public static final By cloneBOM_next=By.xpath("//button[@ng-click='cloneBOM()']");
	public static void set_BOMdocument(String name){
		remove_BOM_document_name="//a[text()='"+name+"']/following-sibling::button";
	}

	public static void set_document(String name){
		remove_document_name="//h4[text()='"+name+"']/../../button";
	}
	public static final By remove_doc_confirmation=By.xpath("//h4[text()='Are you sure you want to remove the link']");
	public static final By yes=By.xpath("//button[@class='btn btn-success']");
	public static String remove_dependency_name;

	public static void set_dependency(String name){
		remove_dependency_name="//td[text()='"+name+"']/preceding::span[@role='button']";
	}

	public static final By remove_dependency_confirmation=By.xpath("//h4[text()='Are you sure you want to remove the dependency?']");
	public static final By ok_button=By.xpath("//button[text()='OK']");
	public static final By add_button=By.xpath("//button[@id='insert_btn']");
	public static final By added_message=By.xpath("//div[@id='modalrecord']"); 
	public static final By close_message=By.xpath("//div[@class='modal-header']//img/..");//div[contains(text(),'View/Edit BOM')]/../button
	public static final By Risk_impact=By.xpath("//select[@ng-model='c.impact']");
	public static final By Risk_status=By.xpath("//select[@ng-model='c.risk_status']");
	public static final By add_document=By.xpath("//button[@ng-click='c.addlink()']");
	public static final By document_name=By.xpath("//input[@id='LinkName']");
	public static final By document_link=By.xpath("//input[@id='LinkURL']");

	public static final By editrisk_BOM_shortdescription=By.xpath("//input[@ng-model='c.newshdesc_value']");
	public static final By editrisk_BOM_description=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.newdesc_value']");
	public static final By editrisk_BOM_impactstatus=By.xpath("//select[@ng-model='c.newimpact_value']");
	public static void setRelease(String release) {
		projectRelease="//*[text()='"+release+"']";
	}

	public static void setBOM(String value){
		addedBomOptionsButton="//td[text()='"+value+"']/..//button";
		addRiskToBOM="//td[text()='"+value+"']/..//button/..//a[text()='Add Risk']";
		addDependencyToBOM="//td[text()='"+value+"']/..//button/..//a[text()='Add a Dependency']";
		view_editBom="//td[text()='"+value+"']/..//button/..//a[text()='View/Edit BOM']";
		copy_cloneBom="//td[text()='"+value+"']/..//button/..//a[text()='Copy/Clone BOM']";
	}
	public static String view_editRiskOptionsButton,view_editRisk;
	public static void setBOM_Risk(String BOM, String Risk) {
		view_editRiskOptionsButton="//td[contains(text(),'"+BOM+"')]/..//td[text()='"+Risk+"']/..//button";
		view_editRisk="//td[contains(text(),'"+BOM+"')]/..//td[text()='"+Risk+"']/..//button/..//a[text()='View/Edit Risk']";
	}
	public static void setWorkstream(String workstream_value) {
		workStream="//h5[text()='"+workstream_value+"']";
		workStreamButton="//h5[text()='"+workstream_value+"']/../..//button";
		workStreamAddBom="//h5[text()='"+workstream_value+"']/../..//button/..//a[text()='Add BOM']";
		workStreamAddRisk="//h5[text()='"+workstream_value+"']/../..//button/..//a[text()='Add Risk']";
		workStream_overall_status="//h5[text()='"+workstream_value+"']/../p";

	}

	public static final By detailed_view=By.xpath("//a[@id='ITSMDetailedViewTab']");
	public static final By green_count=By.xpath("(//span[@class='countText' and text()='Green']/../p)[1]");
	public static final By yellow_count=By.xpath("(//span[@class='countText' and text()='Yellow']/../p)[1]");
	public static final By red_count=By.xpath("(//span[@class='countText' and text()='Red']/../p)[1]");
	public static final By filter=By.xpath("//button[@class='btn-link' and @data-target='#tableFilter']");
	public static final By notrequired_filter=By.xpath("(//*[@id='StateTab']/label)[4]/input");
	public static final By apply=By.xpath("(//button[text()='Apply'])[1]");

	public static final By dependent_BOM_prod_family_dropdown=By.xpath("(//span[text()='Dependent BOM Product Family']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_prod_family_input=By.xpath("//input[@id='s2id_autogen14_search']");
	public static String dependent_BOM_value;
	public static final By dependent_BOM_workstream_dropdown=By.xpath("(//span[text()='Dependent BOM Workstream']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_workstream_input=By.xpath("//input[@id='s2id_autogen16_search']");
	public static final By dependent_BOM_dropdown=By.xpath("//span[text()='Dependent BOM']/../../following-sibling::div//a");
	public static final By dependent_BOM_input=By.xpath("//input[@id='s2id_autogen18_search']");

	public static void setDependent_BOM_Value(String value) {
		dependent_BOM_value="//div[text()='"+value+"']";	
	}
	
	public static final By bom_risk_toggle_button=By.xpath("//input[@ng-change='c.updateView()']/following-sibling::span");

}