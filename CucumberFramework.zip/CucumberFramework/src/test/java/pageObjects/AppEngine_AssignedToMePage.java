package pageObjects;

import org.openqa.selenium.By;

public class AppEngine_AssignedToMePage {
	
	public static final By assignedtome=By.xpath("//a[text()='Assigned To Me']");
	public static final By bom_risk_toggle_button=By.xpath("//input[@ng-change='c.updateView()']/following-sibling::span");
}
