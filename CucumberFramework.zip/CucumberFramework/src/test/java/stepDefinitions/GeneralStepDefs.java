package stepDefinitions;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import supportLibraries.DriverManager;
import supportLibraries.Settings;
import supportLibraries.Util;

import cucumber.api.java.en.Given;

public class GeneralStepDefs extends MasterStepDefs {
	
	private static Properties properties;
	static Logger log = Logger.getLogger(GeneralStepDefs.class);
	WebDriver driver = DriverManager.getWebDriver();

	@Given("^I am in the login page of the application$")
	public void i_am_in_login_page() {
		properties = Settings.getInstance();
		String URL = properties.getProperty("ApplicationUrl");
		driver.get(URL);
        currentScenario.embed(Util.takeScreenshot(driver),"image/png");

		assertTrue(driver.getTitle().contains("Service Portal - Offer Lifecycle Operations"));
	}
}