package stepDefinitions;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import pageObjects.AppEngine_DashboardPage;
import pageObjects.AppEngine_DetailedViewPage;
import pageObjects.LoginPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BOTStepDefs {

	private static Properties properties;
	private static LoginPage loginPage = new LoginPage();
	private static ReusableMethods reusableMethods=new ReusableMethods();
	private static Logger log = Logger.getLogger(BOTStepDefs.class);
	static WebDriver driver = DriverManager.getWebDriver();
	private static String workstream_overall_status,workstream_overall_status_afterupdate;
	private static int notrequired_count=0;
	private static HashMap<String,String> workstream_data=new HashMap<String,String>();

	public static void login() {
		properties = Settings.getInstance();
		byte[] decodedBytes = Base64.getDecoder().decode(properties.getProperty("EncodedPassword").getBytes());

		driver.switchTo().defaultContent();
		driver.switchTo().frame("gsft_main");
		ReusableMethods.enterData(LoginPage.userName,properties.getProperty("Username"));
		ReusableMethods.enterData(LoginPage.password,new String(decodedBytes));

		ReusableMethods.click(LoginPage.login);
	}

	public static void setImpersonateUser(String impersonateUser) {
		ReusableMethods.click(LoginPage.userDropdown);
		ReusableMethods.clickJS(LoginPage.btnImpersonateUser);
		ReusableMethods.click(LoginPage.searchForUser);
		driver.findElement(LoginPage.userSearchInputBox).sendKeys(impersonateUser);
		//ReusableMethods.enterData(LoginPage.userSearchInputBox, impersonateUser);
		LoginPage.setImpersonateUser(impersonateUser);
		ReusableMethods.click(LoginPage.impersonateUser);
	}

	public static void selectRelease(String release) {
		ReusableMethods.waitUntilElementDisabled(LoginPage.dialogBoxImpersonateUser);
		driver.get("https://olasandbox.service-now.com/ola");
		AppEngine_DetailedViewPage.setRelease(release);
		ReusableMethods.click(AppEngine_DetailedViewPage.projectRelease);
		ReusableMethods.click(AppEngine_DetailedViewPage.btnGoToMarket);
		ReusableMethods.click(AppEngine_DetailedViewPage.deliverables_overview);
	}

	public static void addBOM(String workstream, DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(AppEngine_DetailedViewPage.workStream);
			ReusableMethods.waitForLoad();
			ReusableMethods.click(AppEngine_DetailedViewPage.workStreamButton);
			ReusableMethods.click(AppEngine_DetailedViewPage.workStreamAddBom);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.BOM_state,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"Custom BOM Added.");
			ReusableMethods.click(AppEngine_DetailedViewPage.close_message);
		}
	}
	public static void editBOM(String workstream, DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();
		workstream_overall_status=workstreamoverallstatus(workstream);
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(AppEngine_DetailedViewPage.workStream);
			ReusableMethods.waitForLoad();
			String BOM=bomData1.get("BOM");
			AppEngine_DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(AppEngine_DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(AppEngine_DetailedViewPage.view_editBom);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.BOM_state,bomData1.get("State"));
			if(bomData1.get("State").equals("Not Required")){ 
				notrequired_count+=1;		
			}
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			if(!bomData1.get("AddDocumentName").equals("")) {
				ReusableMethods.click(AppEngine_DetailedViewPage.add_document_to_BOM);
				ReusableMethods.enterData(AppEngine_DetailedViewPage.document_name_BOM,bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(AppEngine_DetailedViewPage.document_link_BOM,bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(AppEngine_DetailedViewPage.add);
			}
			if(!bomData1.get("RemoveDocumentName").equals("")) {
				AppEngine_DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(AppEngine_DetailedViewPage.remove_BOM_document_name);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_doc_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(AppEngine_DetailedViewPage.remove_doc_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
				ReusableMethods.click(AppEngine_DetailedViewPage.yes);
			}
			if(!bomData1.get("RemoveDependency").equals("")) {
				AppEngine_DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(AppEngine_DetailedViewPage.remove_dependency_name);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_dependency_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(AppEngine_DetailedViewPage.remove_dependency_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the dependency?");
				ReusableMethods.click(AppEngine_DetailedViewPage.yes);
			}

			ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"BOM Updated.");
			ReusableMethods.click(AppEngine_DetailedViewPage.close_message);
		}
		workstream_overall_status_afterupdate=workstreamoverallstatus(workstream);	
		putWorkstreamData("Workstream Overall Status", workstream_overall_status);
		putWorkstreamData("Workstream Overall Status After Update", workstream_overall_status_afterupdate);
		putWorkstreamData("Workstream Not Required Update Count", String.valueOf(notrequired_count));

	}

	public static void cloneBOM(String workstream, DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(AppEngine_DetailedViewPage.workStream);
			ReusableMethods.waitForLoad();
			String BOM=bomData1.get("BOM");
			AppEngine_DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(AppEngine_DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(AppEngine_DetailedViewPage.copy_cloneBom);		
			ReusableMethods.click(AppEngine_DetailedViewPage.cloneBOM_next);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.clone_BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.clone_BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.BOM_state,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			if(!bomData1.get("AddDocumentName").equals("")) {
				ReusableMethods.click(AppEngine_DetailedViewPage.add_document_to_BOM);
				ReusableMethods.enterData(AppEngine_DetailedViewPage.document_name_BOM,bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(AppEngine_DetailedViewPage.document_link_BOM,bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(AppEngine_DetailedViewPage.add);
			}
			if(!bomData1.get("RemoveDocumentName").equals("")) {
				AppEngine_DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(AppEngine_DetailedViewPage.remove_BOM_document_name);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_doc_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(AppEngine_DetailedViewPage.remove_doc_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
				ReusableMethods.click(AppEngine_DetailedViewPage.yes);
			}
			if(!bomData1.get("RemoveDependency").equals("")) {
				AppEngine_DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(AppEngine_DetailedViewPage.remove_dependency_name);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_dependency_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(AppEngine_DetailedViewPage.remove_dependency_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the dependency?");
				ReusableMethods.click(AppEngine_DetailedViewPage.yes);
			}

			ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"BOM Updated!");
			ReusableMethods.click(AppEngine_DetailedViewPage.close_message);
		}
	}

	public static void putWorkstreamData(String key, String value){
		workstream_data.put(key,value);
	}
	public static String getWorkstreamData(String key){
		return workstream_data.get(key);
	}
	public static HashMap<String,String> getWorkstreamData(){
		return workstream_data;
	}

	public static void addrisk_to_existing_BOM(String BOM, DataTable Riskdata) {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(AppEngine_DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(AppEngine_DetailedViewPage.addRiskToBOM);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_short_desc,riskData1.get("ShortDescription"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_desc,riskData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.Risk_impact,riskData1.get("Impact"));
			ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
			ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message," Risk Submitted! ");
			ReusableMethods.click(AppEngine_DetailedViewPage.close_message); 
		}
	}

	public static void editrisk_to_existing_BOM(String workstream,DataTable Riskdata) {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(AppEngine_DetailedViewPage.workStream);
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[3]//dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[3]//dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[3]//dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						AppEngine_DetailedViewPage.setBOM_Risk(riskData1.get("BOMname"), riskData1.get("Riskname"));
						try{
							if (driver.findElement(By.xpath(AppEngine_DetailedViewPage.view_editRiskOptionsButton)).isDisplayed()) {
								ReusableMethods.click(AppEngine_DetailedViewPage.view_editRiskOptionsButton);
								ReusableMethods.click(AppEngine_DetailedViewPage.view_editRisk);
								break;
							}
						}catch (Exception e) {
							System.out.println("Moving to next page to find the element");
						}
					}
					ReusableMethods.enterData(AppEngine_DetailedViewPage.editrisk_BOM_shortdescription,riskData1.get("ShortDescription"));
					ReusableMethods.enterData(AppEngine_DetailedViewPage.editrisk_BOM_description,riskData1.get("Description"));
					ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.editrisk_BOM_impactstatus,riskData1.get("Impact"));
					ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
					ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
					ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
					ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
					ReusableMethods.waitForLoad();
					String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
					ReusableMethods.softAssertverification(message,"Risk Updated!");
					ReusableMethods.click(AppEngine_DetailedViewPage.close_message); 
				}
			}catch(Exception e) {
				System.out.println("Only one page is there!!");
				AppEngine_DetailedViewPage.setBOM_Risk(riskData1.get("BOMname"), riskData1.get("Riskname"));
				ReusableMethods.click(AppEngine_DetailedViewPage.view_editRiskOptionsButton);
				ReusableMethods.click(AppEngine_DetailedViewPage.view_editRisk);
				ReusableMethods.enterData(AppEngine_DetailedViewPage.editrisk_BOM_shortdescription,riskData1.get("ShortDescription"));
				ReusableMethods.enterData(AppEngine_DetailedViewPage.editrisk_BOM_description,riskData1.get("Description"));
				ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.editrisk_BOM_impactstatus,riskData1.get("Impact"));
				ReusableMethods.selectDataByVisibleText(AppEngine_DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
				ReusableMethods.enterData(AppEngine_DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
				ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
				ReusableMethods.waitForLoad();
				String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
				ReusableMethods.softAssertverification(message," Risk Updated! ");
				ReusableMethods.click(AppEngine_DetailedViewPage.close_message); 
			}
		}
	}

	public static void adddependency_to_existing_BOM(String BOM, DataTable Dependencydata) {
		List<Map<String, String>> dependencydata =Dependencydata.asMaps(String.class, String.class);
		int size = dependencydata.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> dependencydata1 = dependencydata.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(AppEngine_DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(AppEngine_DetailedViewPage.addDependencyToBOM);
			ReusableMethods.click(AppEngine_DetailedViewPage.dependent_BOM_prod_family_dropdown);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.dependent_BOM_prod_family_input,dependencydata1.get("DependentBOMProductFamily"));
			AppEngine_DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMProductFamily"));
			ReusableMethods.click(AppEngine_DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(AppEngine_DetailedViewPage.dependent_BOM_workstream_dropdown);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.dependent_BOM_workstream_input,dependencydata1.get("DependentBOMWorkstream"));
			AppEngine_DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMWorkstream"));
			ReusableMethods.click(AppEngine_DetailedViewPage.dependent_BOM_value);

			ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"Dependency added.");
			ReusableMethods.click(AppEngine_DetailedViewPage.close_message); 

		}		
	}

	public static String workstreamoverallstatus(String workstream) {	
		workstream_overall_status=driver.findElement(By.xpath(AppEngine_DetailedViewPage.workStream_overall_status)).getText();
		return workstream_overall_status;
	}

	public static void add_document(DataTable Documentdata) {

		ReusableMethods.click(AppEngine_DashboardPage.dashboard);
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			ReusableMethods.click(AppEngine_DetailedViewPage.add_document);
			ReusableMethods.enterData(AppEngine_DetailedViewPage.document_name,documentdata1.get("DocumentName"));
			ReusableMethods.enterData(AppEngine_DetailedViewPage.document_link,documentdata1.get("DocumentLinks"));
			ReusableMethods.click(AppEngine_DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitUntilElementEnabled(AppEngine_DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(AppEngine_DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message," The Document Link has been added. ");
			ReusableMethods.click(AppEngine_DetailedViewPage.close_message); 
		}
	}

	public static void remove_document(DataTable Documentdata) {
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			AppEngine_DetailedViewPage.set_document(documentdata1.get("DocumentName"));
			ReusableMethods.click(AppEngine_DetailedViewPage.remove_document_name);
			ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_doc_confirmation);
			ReusableMethods.waitForLoad();				
			String message=driver.findElement(AppEngine_DetailedViewPage.remove_doc_confirmation).getText();
			ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
			ReusableMethods.click(AppEngine_DetailedViewPage.yes);
		}
	}
	public static void columnname_and_order_verification_for_a_workstream(DataTable Workstreams) {
		List<Map<String, String>> workstream =Workstreams.asMaps(String.class, String.class);
		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = workstream.get(anchor);
			ReusableMethods.waitForLoad();
			AppEngine_DetailedViewPage.setWorkstream(documentdata1.get("Workstreams"));
			ReusableMethods.click(AppEngine_DetailedViewPage.workStream);

			//BOM table validation
			List<String> expected=new ArrayList<String>();
			expected.add("BOM Category");
			expected.add("BOM Name");
			expected.add("Assigned to");
			expected.add("State");
			expected.add("Status");
			expected.add("Due Date");
			expected.add("Partner");
			List<String> actual=new ArrayList<String>();
			int n=driver.findElements(By.xpath("//thead//th")).size();
			for(int i=6;i<=12;i++) {
				String value=driver.findElement(By.xpath("(//thead//th)["+i+"]")).getText();
				value.trim();
				actual.add(value);
			}
			boolean result=expected.equals(actual);
			ReusableMethods.softAssertverification(result, true);

			//Risk table validation
			List<String> expected1=new ArrayList<String>();
			expected1.add("Applicable To");
			expected1.add("Risk Name");
			expected1.add("Assigned to");
			expected1.add("Status");
			expected1.add("Impact");
			expected1.add("Initiate Date");
			expected1.add("Due Date");
			List<String> actual1=new ArrayList<String>();
			for(int j=22;j<=28;j++) {
				String value=driver.findElement(By.xpath("(//thead//th)["+j+"]")).getText();
				value.trim();
				actual1.add(value);
			}
			boolean result1=expected1.equals(actual1);
			ReusableMethods.softAssertverification(result1, true);
		}
		AppEngine_DetailedViewPage.setWorkstream("//h5[contains(text(),'All Workstreams')]");
		ReusableMethods.click(AppEngine_DetailedViewPage.workStream);
	}
}
