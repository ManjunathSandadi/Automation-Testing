package supportLibraries;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class ReusableMethods {

	static WebDriver driver = DriverManager.getWebDriver();
	private static long timeOutInSeconds = 600;

	/**
	 * Function to wait until the specified element is visible
	 * 
	 * @param by
	 *            The {@link WebDriver} locator used to identify the element
	 * @param timeOutInSeconds
	 *            The wait timeout in seconds
	 */
	public static void waitUntilElementVisible(By by) {
		(new WebDriverWait(driver, Duration.ofSeconds(timeOutInSeconds))).until(ExpectedConditions
				.visibilityOfElementLocated(by));
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}

	/**
	 * Function to wait until the specified element is enabled
	 * 
	 * @param by
	 *            The {@link WebDriver} locator used to identify the element
	 * @param timeOutInSeconds
	 *            The wait timeout in seconds
	 */
	public static void waitUntilElementEnabled(By by) {
		(new WebDriverWait(driver, Duration.ofSeconds(timeOutInSeconds))).until(ExpectedConditions
				.elementToBeClickable(by));
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}

	/**
	 * Function to wait until the specified element is disabled
	 * 
	 * @param by
	 *            The {@link WebDriver} locator used to identify the element
	 * @param timeOutInSeconds
	 *            The wait timeout in seconds
	 */
	public static void waitUntilElementDisabled(By by) {
		(new WebDriverWait(driver, Duration.ofSeconds(timeOutInSeconds))).until(ExpectedConditions
				.not(ExpectedConditions.elementToBeClickable(by)));
	}

	public static void enterData(By element, String value) {
		if (!value.equals("")) {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			waitForLoad();
			driver.findElement(element).clear();
			driver.findElement(element).click();
			driver.findElement(element).sendKeys(value);
			driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
			driver.findElement(element).sendKeys(Keys.TAB);
		}
	}

	public static void click(By element) {
		waitUntilElementVisible(element);
		waitUntilElementEnabled(element);
		waitForLoad();
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		driver.findElement(element).click();
	}

	public static void clickJS(By element) {
		waitUntilElementVisible(element);
		waitUntilElementEnabled(element);
		waitForLoad();
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", driver.findElement(element));
	}

	public static void click(String element) {
		waitUntilElementVisible((By.xpath(element)));
		waitUntilElementEnabled((By.xpath(element)));
		waitForLoad();
		driver.findElement(By.xpath(element)).click();
	}

	public static void selectDataByVisibleText(By element, String value) {
		if(!value.equals("")) {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			waitForLoad();
			Select select=new Select(driver.findElement(element));
			select.selectByVisibleText(value);		
		}
	}

	public static void waitForLoad() {
		try {
			new WebDriverWait(driver,Duration.ofSeconds(timeOutInSeconds)).until(webDriver -> ((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState").equals("complete"));
		} catch (Throwable error) {
			System.out.println(error);
			System.out.println("TimeOut Failed");
		}
	}

	public static void softAssertverification(String actual_message, String expected_message) {
		waitForLoad();
		SoftAssert softassert=new SoftAssert();
		softassert.assertEquals(actual_message, expected_message,"Message validation completed succesfully");
	}
	public static void softAssertverification(boolean actual_status, boolean expected_status) {
		waitForLoad();
		SoftAssert softassert=new SoftAssert();
		softassert.assertEquals(actual_status, expected_status,"Validation completed successfully");
	}
}