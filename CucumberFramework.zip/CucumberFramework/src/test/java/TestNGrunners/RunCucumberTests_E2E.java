package TestNGrunners;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.*;
import org.testng.annotations.*;

import com.github.mkolisnyk.cucumber.reporting.CucumberDetailedResults;
import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.*;
import supportLibraries.*;

//@ExtendedCucumberOptions(

		//jsonReport = "target/cucumber-report/Smoke/cucumber.json", jsonUsageReport = "target/cucumber-report/Smoke/cucumber-usage.json", outputFolder = "target/cucumber-report/E2E", detailedReport = true, detailedAggregatedReport = true, overviewReport = true, usageReport = true)

/**
 * Please notice that stepDefinations.CukeHooks class is in
 * the same package as the steps definitions. It has two methods that are
 * executed before or after scenario. I'm using it to delete cookies and take a
 * screenshot if scenario fails.
 */
@CucumberOptions(
		features = "src/test/resources/features/OLA_E2E.feature",
		glue = {"stepDefinitions"},
		tags = {"@E2E"}, monochrome = true, 
		plugin ={"pretty", "html:target/cucumber-report/E2E"})

public class RunCucumberTests_E2E {
	private  TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun=true)
	public void setUpClass() {
		testNGCucumberRunner=new TestNGCucumberRunner(this.getClass());
	}

	@Test(dataProvider="features")
	public void feature(CucumberFeatureWrapper cucumberfeature) {
		testNGCucumberRunner.runCucumber(cucumberfeature.getCucumberFeature());
	}

	@DataProvider 
	public Object [][] features(){
	    if(testNGCucumberRunner == null){
	        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	    }
		return testNGCucumberRunner.provideFeatures();
	}
	
	@AfterTest
	private void test() {
		generateCustomReports();
		copyReportsFolder();
		testNGCucumberRunner.finish();
	}

	private void generateCustomReports() {

		CucumberResultsOverview overviewReports = new CucumberResultsOverview();
		overviewReports.setOutputDirectory("target");
		overviewReports.setOutputName("cucumber-results");
		overviewReports.setSourceFile("target/cucumber-report/E2E/cucumber.json");
		try {
			overviewReports.executeFeaturesOverviewReport();
		} catch (Exception e) {
			e.printStackTrace();
		}

		CucumberDetailedResults detailedResults = new CucumberDetailedResults();
		detailedResults.setOutputDirectory("target");
		detailedResults.setOutputName("cucumber-results");
		detailedResults
		.setSourceFile("target/cucumber-report/E2E/cucumber.json");
		detailedResults.setScreenShotLocation("./screenshot");
		try {
			detailedResults.executeDetailedResultsReport(false, true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void copyReportsFolder() {

		String timeStampResultPath = TimeStamp.getInstance();
		File sourceCucumber = new File(Util.getTargetPath());
		File destCucumber = new File(timeStampResultPath);
		try {
			FileUtils.copyDirectory(sourceCucumber, destCucumber);
			try {
				FileUtils.cleanDirectory(sourceCucumber);
			} catch (Exception e) {

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		TimeStamp.reportPathWithTimeStamp = null;
	}
}